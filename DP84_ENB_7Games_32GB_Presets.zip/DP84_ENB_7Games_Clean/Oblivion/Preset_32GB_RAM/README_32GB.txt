Preset_32GB_RAM - Oblivion
---------------------------------
Versione ottimizzata per sistemi con 32 GB di RAM o più.
Modifiche principali:
- VideoMemorySizeMb=16384
- ReservedMemorySizeMb=1024

Installazione: copiare i file nella root del gioco o usare la cartella 'with_enblocal' se presente.
Consiglio: utilizzare questa versione solo su sistemi con almeno 32 GB di RAM fisica.
