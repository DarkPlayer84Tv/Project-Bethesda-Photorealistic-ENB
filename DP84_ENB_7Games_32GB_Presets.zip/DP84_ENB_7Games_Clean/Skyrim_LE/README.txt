DP84 ENB - Skyrim_LE
====================
Preset pulito per Skyrim_LE. Copia i file nella root del gioco.
