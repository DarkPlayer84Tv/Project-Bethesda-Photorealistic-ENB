DP84 ENB - Multi-Game Clean Pack
Versione pulita: solo file .ini e README (nessun file binario/DLL).
Struttura: per ogni gioco c'è la cartella principale con enbseries.ini + enblocal.ini + README,
e la sottocartella 'with_enblocal' con file di supporto testuali per facilitare l'installazione.
Consigli: copiare SOLO i file necessari per il gioco e testare uno alla volta.
