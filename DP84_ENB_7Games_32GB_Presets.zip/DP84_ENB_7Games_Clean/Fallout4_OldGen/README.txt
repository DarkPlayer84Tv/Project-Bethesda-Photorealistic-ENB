DP84 ENB - Fallout4_OldGen
====================
Preset pulito per Fallout4_OldGen. Copia i file nella root del gioco.
