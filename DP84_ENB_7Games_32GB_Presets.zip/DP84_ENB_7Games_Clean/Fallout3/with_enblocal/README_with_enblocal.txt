Cartella 'with_enblocal' - versione pulita (solo file testuali)
Contenuto:
- enbseries.ini
- enblocal.ini
- enbcolor.ini (color correction)
- enbdepthoffield.ini (DOF)
- enbpostprocessing.ini (bloom/tonemap)
- enbssao.ini (SSAO settings)
- enbreflections.ini (SSR/reflections)

I file sono solo testuali e modificabili. Copia il contenuto della cartella 'with_enblocal' nella root del gioco.
NON includo DLL o file binari. Fai sempre backup dei file ENB esistenti prima di sovrascrivere.

; File for Fallout3
