DP84 ENB - Fallout4_NextGen
====================
Preset pulito per Fallout4_NextGen. Copia i file nella root del gioco.
