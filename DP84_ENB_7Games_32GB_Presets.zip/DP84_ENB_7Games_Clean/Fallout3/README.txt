DP84 ENB - Fallout3
====================
Preset pulito per Fallout3. Copia i file nella root del gioco.
