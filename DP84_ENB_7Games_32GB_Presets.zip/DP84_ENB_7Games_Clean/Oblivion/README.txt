DP84 ENB - Oblivion
====================
Preset pulito per Oblivion. Copia i file nella root del gioco.
