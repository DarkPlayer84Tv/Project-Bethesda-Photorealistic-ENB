DP84 ENB - NewVegas
====================
Preset pulito per NewVegas. Copia i file nella root del gioco.
